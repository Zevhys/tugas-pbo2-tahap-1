package crud;

import db_config.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;

public class pendaftaranCrud {

    public String VAR_NOMOR_REGISTRASI = null;
    public String VAR_TANGGAL_REGISTRASI = null;
    public String VAR_NOMOR_REKAM_MEDIS = null;
    public String VAR_KODE_DOKTER = null;
    public String VAR_KODE_POLIKLINIK = null;
    public String VAR_KODE_BAYAR = null;
    public boolean validasi = false;

    public void simpanPendaftaran(String nomorRegistrasi, String tanggalRegistrasi, String nomorRekamMedis, String kodeDokter, String kodePoliklinik, String kodeBayar) {

        try (Connection conn = koneksi.getKoneksi()) {
            String sql = "insert into pendaftaran(nomor_registrasi, tanggal_registrasi, nomor_rekam_medis, kode_dokter, kode_poliklinik, kode_bayar) value(?, ?, ?, ?, ?, ?)";
            String cekPrimary = "select * from pendaftaran where nomor_registrasi = ?";

            try (PreparedStatement check = conn.prepareStatement(cekPrimary)) {
                check.setString(1, nomorRekamMedis);
                ResultSet data = check.executeQuery();

                if (data.next()) {
                    JOptionPane.showMessageDialog(null, "Nomor Registrasi Sudah Terdaftar");
                    this.VAR_TANGGAL_REGISTRASI = data.getString("tanggal_registrasi");
                    this.VAR_NOMOR_REKAM_MEDIS = data.getString("nomor_rekam_medis");
                    this.VAR_KODE_DOKTER = data.getString("kode_dokter");
                    this.VAR_KODE_POLIKLINIK = data.getString("kode_poliklinik");
                    this.VAR_KODE_BAYAR = data.getString("kode_bayar");
                    this.validasi = true;
                } else {
                    this.validasi = false;
                    this.VAR_TANGGAL_REGISTRASI = null;
                    this.VAR_NOMOR_REKAM_MEDIS = null;
                    this.VAR_KODE_DOKTER = null;
                    this.VAR_KODE_POLIKLINIK = null;
                    this.VAR_KODE_BAYAR = null;

                    try (PreparedStatement perintah = conn.prepareStatement(sql)) {
                        perintah.setString(1, nomorRegistrasi);
                        perintah.setString(2, tanggalRegistrasi);
                        perintah.setString(3, nomorRekamMedis);
                        perintah.setString(4, kodeDokter);
                        perintah.setString(5, kodePoliklinik);
                        perintah.setString(6, kodeBayar);
                        perintah.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error SQL saat Simpan: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Umum saat Simpan: " + e.getMessage());
        }
    }

    public void ubahPendaftaran(String nomorRegistrasi, String tanggalRegistrasi, String nomorRekamMedis, String kodeDokter, String kodePoliklinik, String kodeBayar) {
        String sql = "update pendaftaran set tanggal_registrasi = ?, nomor_rekam_medis = ?, "
                + "kode_dokter = ?, kode_poliklinik = ?, kode_bayar = ? "
                + "where nomor_registrasi = ?";

        try (Connection conn = koneksi.getKoneksi(); PreparedStatement perintah = conn.prepareStatement(sql)) {

            perintah.setString(1, tanggalRegistrasi);
            perintah.setString(2, nomorRekamMedis);
            perintah.setString(3, kodeDokter);
            perintah.setString(4, kodePoliklinik);
            perintah.setString(5, kodeBayar);
            perintah.setString(6, nomorRegistrasi);

            int rowsAffected = perintah.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
            } else {
                JOptionPane.showMessageDialog(null, "Nomor Registrasi tidak ditemukan. Data GAGAL diubah.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saat Ubah: " + e.getMessage());
        }
    }

    public void hapusPendaftaran(String nomorRegistrasi) {
        String sql = "delete from pendaftaran where nomor_registrasi = ?";

        try (Connection conn = koneksi.getKoneksi(); PreparedStatement perintah = conn.prepareStatement(sql)) {

            perintah.setString(1, nomorRegistrasi);

            int rowsAffected = perintah.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
            } else {
                JOptionPane.showMessageDialog(null, "Nomor Registrasi tidak ditemukan. Data GAGAL dihapus.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saat Hapus: " + e.getMessage());
        }
    }

    public void tampilDataPendaftaran(JTable komponenTable, String SQL) {
        DefaultTableModel modelTable = new DefaultTableModel();

        modelTable.addColumn("Nomor Registrasi");
        modelTable.addColumn("Tanggal Registrasi");
        modelTable.addColumn("Nomor Rekam Medis");
        modelTable.addColumn("Kode Dokter");
        modelTable.addColumn("Kode Poliklinik");
        modelTable.addColumn("Kode Bayar");

        try (Connection conn = koneksi.getKoneksi(); Statement perintah = conn.createStatement(); ResultSet data = perintah.executeQuery(SQL)) {

            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();

            while (data.next()) {
                Object[] row = new Object[jumKolom];
                for (int i = 1; i <= jumKolom; i++) {
                    row[i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
            }

            komponenTable.setModel(modelTable);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error SQL saat Tampil Data: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Umum saat Tampil Data: " + e.getMessage());
        }
    }
}
