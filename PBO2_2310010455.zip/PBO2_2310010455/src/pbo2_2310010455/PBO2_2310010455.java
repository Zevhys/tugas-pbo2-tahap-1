package pbo2_2310010455;
import frame.menu;

public class PBO2_2310010455 {
    public static void main(String[] args) {
        new menu().setVisible(true);
    }
}
